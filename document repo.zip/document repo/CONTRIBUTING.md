# Contributing to Moonshot

Thanks for your interest in improving Moonshot. This document covers how
to set up a development environment, the quality gates your change must pass,
and the workflow for getting it merged.

By participating in this project you agree to abide by the
[Code of Conduct](CODE_OF_CONDUCT.md).

## Workflow

1. **Branch.** Every change goes through a branch and pull request — including
   refactors, one-line fixes, and docs. Name branches `<type>/<short-desc>`
   (e.g. `feat/peer-gossip-retry`, `fix/signing-key-load-race`,
   `docs/api-reference`).
2. **Commit** using [Conventional Commits](https://www.conventionalcommits.org/)
   (`feat(scope): …`, `fix: …`, `refactor: …`, `docs: …`).
3. **Keep PRs focused.** A fix PR fixes the thing it was opened for; adjacent
   refactors become their own PRs. Bundling expands blast radius and
   complicates revert.
4. **Open a pull request** against `main` with a summary of what changed and
   how to test it. Make sure CI is green.
5. **Squash merge** once approved (`--squash`), and delete the branch.


## Reporting bugs and requesting features

Use the issue templates under
[`.github/ISSUE_TEMPLATE`](.github/ISSUE_TEMPLATE). For security
vulnerabilities, **do not open a public issue** — follow
[SECURITY.md](SECURITY.md) instead.
