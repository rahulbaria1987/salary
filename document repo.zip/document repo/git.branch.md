This is mmon project documentation's git repo
The following are the 5 branches:

main
frontend-doc
backend-doc
smart-contract-doc
management-doc

We plan to continuously update resources and documents as the project progresses.