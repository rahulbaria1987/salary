# Changelog

All notable changes to MMON are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.0]

First public release of MMON under its own name and package.

### Highlights

- **Proof-of-work ledger** 
- **Dual surface:** 
- **Permissioned network** 
- **Stateless per-request authentication** 
- **Anti-spam controls:** 
- **Schema migrations** 
- **Supply-chain hardening:** 
